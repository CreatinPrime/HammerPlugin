Dieses ResourcePack enthält die Hammer-Texturen für dein HammerPlugin.
Dateipfad (relativ zum ZIP-Root):
assets/minecraft/textures/item/
assets/minecraft/models/item/
pack.mcmeta

CustomModelData Zuordnung (verwende diese IDs in deinem Plugin via ItemMeta#setCustomModelData):

- wooden_hammer.png -> CustomModelData = 1001 (Override in wooden_axe.json)
- stone_hammer.png -> CustomModelData = 1002 (Override in stone_axe.json)
- iron_hammer.png -> CustomModelData = 1003 (Override in iron_axe.json)
- golden_hammer.png -> CustomModelData = 1004 (Override in golden_axe.json)
- diamond_hammer.png -> CustomModelData = 1005 (Override in diamond_axe.json)
- netherite_hammer.png -> CustomModelData = 1006 (Override in netherite_axe.json)